import rag_chat

if __name__ == "__main__":
    rag_chat.main()
