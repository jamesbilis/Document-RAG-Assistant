from __future__ import annotations

import os
import sys
from dataclasses import dataclass
from getpass import getpass
from pathlib import Path
from typing import Any, Dict, List, Tuple

import chromadb
from sentence_transformers import SentenceTransformer
from huggingface_hub import InferenceClient


# -----------------------------
#Local in CWD
# -----------------------------
CWD = Path.cwd()
DEFAULT_CHROMA_PATH = str(CWD / "chroma_db")
DEFAULT_COLLECTION = "documents_project4"  

DEFAULT_MODEL = "meta-llama/Meta-Llama-3-8B-Instruct"
EMBED_MODEL = "sentence-transformers/all-MiniLM-L6-v2"

SHOW_SOURCES = True


SYSTEM_PROMPT = """You are a Retrieval-Augmented Generation (RAG) assistant.

STRICT RULES:
- Answer the user's question using ONLY the provided CONTEXT.
- Do NOT use any outside knowledge.
- If the answer is not explicitly stated in the CONTEXT, reply exactly:
  "I don't know based on the provided context."
- Do NOT guess.
"""


@dataclass
class RAG:
    client: InferenceClient
    embedder: SentenceTransformer
    collection: Any  


def _safe_get_env_token() -> str:
    return os.getenv("HF_TOKEN") or os.getenv("HUGGINGFACEHUB_API_TOKEN") or ""


def load_rag(
    model: str,
    token: str,
    chroma_path: str = DEFAULT_CHROMA_PATH,
    collection_name: str = DEFAULT_COLLECTION,
) -> RAG:
    client = InferenceClient(model=model, token=token if token else None)
    embedder = SentenceTransformer(EMBED_MODEL)
    chroma = chromadb.PersistentClient(path=chroma_path)
    collection = chroma.get_or_create_collection(name=collection_name)
    if collection.count() == 0:
        raise RuntimeError(
            "The knowledge base is empty. Run 'python ingest.py' before starting the chat."
        )
    return RAG(client=client, embedder=embedder, collection=collection)


def retrieve(rag: RAG, query: str, k: int = 3) -> List[Dict[str, Any]]:
    q_emb = rag.embedder.encode([query], normalize_embeddings=True).tolist()[0]

    res = rag.collection.query(
        query_embeddings=[q_emb],
        n_results=int(k),
        include=["documents", "metadatas", "distances"],
    )

    docs = res.get("documents", [[]])[0] if res else []
    metas = res.get("metadatas", [[]])[0] if res else []

    items: List[Dict[str, Any]] = []
    for i in range(min(len(docs), len(metas))):
        text = (docs[i] or "").strip()
        meta = metas[i] or {}
        src = meta.get("source") or meta.get("file") or meta.get("filename") or "unknown"
        if text:
            items.append({"text": text, "source": str(src)})
    return items


def build_prompt(context_items: List[Dict[str, Any]], user_question: str) -> Tuple[str, List[str]]:
    if not context_items:
        context_block = "NO_CONTEXT"
        sources: List[str] = []
    else:
        blocks = []
        sources = []
        for idx, it in enumerate(context_items, start=1):
            blocks.append(f"[Chunk {idx}]\n{it['text']}")
            sources.append(it["source"])
        context_block = "\n\n".join(blocks)

    prompt = f"""CONTEXT:
{context_block}

QUESTION:
{user_question}

INSTRUCTIONS:
Answer using ONLY the CONTEXT. If not found, say: "I don't know based on the provided context."
"""
    
    seen = set()
    uniq = []
    for s in sources:
        if s not in seen:
            uniq.append(s)
            seen.add(s)

    return prompt, uniq


def call_llm_chat(rag: RAG, prompt: str, temperature: float = 0.2, max_tokens: int = 350) -> str:
    messages = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": prompt},
    ]
    resp = rag.client.chat_completion(
        messages=messages,
        max_tokens=int(max_tokens),
        temperature=float(temperature),
    )
    try:
        return resp.choices[0].message.content.strip()
    except Exception:
        return str(resp).strip()


def ask_rag(rag: RAG, question: str, k: int = 3) -> Tuple[str, List[str]]:
    ctx = retrieve(rag, question, k=k)
    prompt, sources = build_prompt(ctx, question)
    answer = call_llm_chat(rag, prompt)
    return answer, sources


def main() -> None:
    print("=== Project 4: CLI RAG Chatbot (ChromaDB) ===")
    print(f"Docs folder:   {CWD / 'documents_project4'}")
    print(f"Chroma folder: {CWD / 'chroma_db'}\n")

    token = getpass("Hugging Face token (hidden, or blank to use env HF_TOKEN): ").strip()
    if not token:
        token = _safe_get_env_token()

    model = input(f"Model [{DEFAULT_MODEL}]: ").strip() or DEFAULT_MODEL

    chroma_path = os.getenv("CHROMA_PATH", DEFAULT_CHROMA_PATH)
    collection_name = os.getenv("CHROMA_COLLECTION", DEFAULT_COLLECTION)

    print("\nLoading embedder + Chroma + HF client...")
    rag = load_rag(model=model, token=token, chroma_path=chroma_path, collection_name=collection_name)

    print("\nType 'exit' to quit.\n")
    while True:
        q = input("You: ").strip()
        if not q:
            continue
        if q.lower() in {"exit", "quit"}:
            break

        try:
            answer, sources = ask_rag(rag, q, k=3)
        except Exception as e:
            print(f"\nAssistant: Error calling model: {e}\n")
            continue

        print(f"\nAssistant: {answer}\n")
        if SHOW_SOURCES and sources:
            print("Sources:", ", ".join(sources), "\n")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nExiting...")
        sys.exit(0)
