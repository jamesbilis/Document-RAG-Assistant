from __future__ import annotations

from pathlib import Path

import chromadb
from chromadb.config import Settings
from pypdf import PdfReader
from sentence_transformers import SentenceTransformer


# -----------------------------
# Folder in CWD
# -----------------------------
CWD = Path.cwd()
DOCS_DIR = CWD / "documents_project4"     
CHROMA_DIR = CWD / "chroma_db"            
COLLECTION_NAME = "documents_project4"    

MODEL_NAME = "sentence-transformers/all-MiniLM-L6-v2"


def read_txt(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="ignore")


def read_pdf(path: Path) -> str:
    reader = PdfReader(str(path))
    pages = []
    for page in reader.pages:
        txt = (page.extract_text() or "").strip()
        if txt:
            pages.append(txt)
    return "\n\n".join(pages)


def chunk_text(text: str, chunk_size: int = 900, overlap: int = 150) -> list[str]:
    """
    Sliding-window chunking. Works for arbitrary text files.
    """
    text = " ".join(text.split())
    if not text:
        return []

    chunks: list[str] = []
    i = 0
    n = len(text)
    while i < n:
        end = min(i + chunk_size, n)
        chunks.append(text[i:end])
        if end == n:
            break
        i = max(0, end - overlap)
    return chunks


def main() -> None:
    DOCS_DIR.mkdir(parents=True, exist_ok=True)
    CHROMA_DIR.mkdir(parents=True, exist_ok=True)

    files = sorted([p for p in DOCS_DIR.glob("*") if p.is_file()])
    if not files:
        print(f"No documents found in: {DOCS_DIR}")
        print("Add .txt files (and optionally .pdf), then run ingest.py again.")
        return

    print("Loading embedding model...")
    embedder = SentenceTransformer(MODEL_NAME)

    print("Opening ChromaDB (local persistence)...")
    client = chromadb.PersistentClient(
        path=str(CHROMA_DIR),
        settings=Settings(anonymized_telemetry=False),
    )
    collection = client.get_or_create_collection(name=COLLECTION_NAME)

    ids: list[str] = []
    docs: list[str] = []
    metas: list[dict] = []

    for fp in files:
        suf = fp.suffix.lower()
        if suf == ".txt":
            raw = read_txt(fp)
        elif suf == ".pdf":
            raw = read_pdf(fp)
        else:
            continue

        for idx, piece in enumerate(chunk_text(raw)):
            chunk_id = f"{fp.name}::chunk{idx}"
            ids.append(chunk_id)
            docs.append(piece)
            metas.append({"source": fp.name, "chunk": idx})

    if not docs:
        print("No usable text extracted (documents empty or unreadable).")
        return

    print(f"Embedding {len(docs)} chunks...")
    embeddings = embedder.encode(docs, normalize_embeddings=True).tolist()

    # Replace existing IDs if re-running
    try:
        collection.delete(ids=ids)
    except Exception:
        pass

    print("Writing to ChromaDB...")
    collection.add(ids=ids, documents=docs, embeddings=embeddings, metadatas=metas)

    print("\nDone.")
    print(f"Collection: {COLLECTION_NAME}")
    print(f"Chunks stored: {len(docs)}")
    print(f"Docs folder: {DOCS_DIR}")
    print(f"Chroma path: {CHROMA_DIR}")


if __name__ == "__main__":
    main()
